Licenses
========

This directory holds license and credit information for the affiliated package,
works the affiliated package is derived from, and/or datasets.
