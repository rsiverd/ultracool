.. _changelog:

*********
Changelog
*********

.. include:: ../CHANGES.rst
