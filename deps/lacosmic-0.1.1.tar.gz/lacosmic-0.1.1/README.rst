lacosmic
========

A python-based version of `LACosmic`_.

.. image:: https://travis-ci.org/larrybradley/lacosmic.svg?branch=master
  :target: https://travis-ci.org/larrybradley/lacosmic

.. image:: https://coveralls.io/repos/larrybradley/lacosmic/badge.svg?branch=master
  :target: https://coveralls.io/r/larrybradley/lacosmic

.. image:: https://readthedocs.org/projects/lacosmic/badge/?version=latest
  :target: http://lacosmic.readthedocs.io/
  :alt: Latest Documentation Status

.. _photutils: https://github.com/astropy/photutils
.. _LACosmic: http://www.astro.yale.edu/dokkum/lacosmic/
